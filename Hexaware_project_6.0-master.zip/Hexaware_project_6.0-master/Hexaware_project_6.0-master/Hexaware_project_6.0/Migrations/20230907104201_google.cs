﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hexaware_project_6._0.Migrations
{
    public partial class google : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK__Device__PATIENT___4D94879B",
                table: "Device");

            migrationBuilder.DropForeignKey(
                name: "FK__Nurse__DEVICE_ID__5165187F",
                table: "Nurse");

            migrationBuilder.DropForeignKey(
                name: "FK__Nurse__PATIENT_I__5070F446",
                table: "Nurse");

            migrationBuilder.DropIndex(
                name: "IX_Nurse_DEVICE_ID",
                table: "Nurse");

            migrationBuilder.AlterColumn<int>(
                name: "PATIENT_ID",
                table: "Nurse",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "DEVICE_ID",
                table: "Nurse",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "PATIENT_ID",
                table: "Device",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Device_Patient_PATIENT_ID",
                table: "Device",
                column: "PATIENT_ID",
                principalTable: "Patient",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Nurse_Patient_PATIENT_ID",
                table: "Nurse",
                column: "PATIENT_ID",
                principalTable: "Patient",
                principalColumn: "ID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Device_Patient_PATIENT_ID",
                table: "Device");

            migrationBuilder.DropForeignKey(
                name: "FK_Nurse_Patient_PATIENT_ID",
                table: "Nurse");

            migrationBuilder.AlterColumn<int>(
                name: "PATIENT_ID",
                table: "Nurse",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "DEVICE_ID",
                table: "Nurse",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "PATIENT_ID",
                table: "Device",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Nurse_DEVICE_ID",
                table: "Nurse",
                column: "DEVICE_ID");

            migrationBuilder.AddForeignKey(
                name: "FK__Device__PATIENT___4D94879B",
                table: "Device",
                column: "PATIENT_ID",
                principalTable: "Patient",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK__Nurse__DEVICE_ID__5165187F",
                table: "Nurse",
                column: "DEVICE_ID",
                principalTable: "Device",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK__Nurse__PATIENT_I__5070F446",
                table: "Nurse",
                column: "PATIENT_ID",
                principalTable: "Patient",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
